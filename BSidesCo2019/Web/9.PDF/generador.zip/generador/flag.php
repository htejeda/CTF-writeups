<?php

$flag = "BSidesCo{flag}";
